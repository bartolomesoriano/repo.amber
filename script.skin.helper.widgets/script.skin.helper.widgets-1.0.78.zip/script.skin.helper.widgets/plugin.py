#!/usr/bin/python
# -*- coding: utf-8 -*-

'''main plugin entrypoint'''

import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), "resources", "lib"))
import main

main.Main()
